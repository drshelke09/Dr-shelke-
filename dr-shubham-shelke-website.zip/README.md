# Dr. Shubham Shelke — Website

Plain HTML/CSS/JS site. No build tools, no dependencies to install.

```
index.html          Home page (all main sections)
privacy.html         Privacy Policy
terms.html            Terms of Use
disclaimer.html      Medical Disclaimer
css/style.css        All styling
js/config.js         Every editable detail (name, numbers, links) — edit this file
js/main.js           Nav, FAQ accordion, WhatsApp form logic
robots.txt            Search engine crawl rules
sitemap.xml          Search engine page list
```

## Step 1 — Run it locally

No install needed. Just open `index.html` in any web browser by double-tapping/double-clicking it.

(Optional, for a more realistic local test: if you have Python installed, run `python3 -m http.server` inside this folder and open `http://localhost:8000` — this is only needed if you want to test things like relative links exactly as they'll behave online.)

## Step 2 — Upload to GitHub from your phone

1. Open the **GitHub** app (or github.com in your phone browser) and sign in.
2. Create a new repository — e.g. `dr-shubham-shelke-website`. Keep it Public if you want free GitHub Pages hosting.
3. In the repo, use **Add file → Upload files** and upload every file in this folder, keeping the `css/` and `js/` folders intact (upload them as folders, or create the folders in GitHub first and upload the files into them).
4. Commit the upload.

## Step 3 — Deploy it

**Option A — GitHub Pages (simplest, free):**
1. In the repo, go to **Settings → Pages**.
2. Under "Build and deployment", set the source branch to `main` (root folder).
3. Save. GitHub will give you a live link like `https://yourusername.github.io/dr-shubham-shelke-website/` within a minute or two.

**Option B — Vercel:**
1. Go to vercel.com and sign in with your GitHub account.
2. Click **New Project**, select this repository, and click **Deploy** (no configuration needed — it's a static site).
3. Vercel gives you a live link immediately, and redeploys automatically every time you push a change to GitHub.

Once you have your live URL, replace `YOUR-DOMAIN-HERE` in `robots.txt` and `sitemap.xml` with it.

## Step 4 — Placeholders to replace before going public

Open **`js/config.js`** — everything the site displays comes from this one file:

| Already filled in | Still a placeholder — needs your input |
|---|---|
| Doctor name | Medical registration number |
| Qualification (MBBS) | Clinic name |
| Medical college | Clinic address |
| Phone number | Consultation timings |
| WhatsApp number | Languages spoken |
| Email | Areas of clinical interest |
| | Google Maps link |
| | Instagram / Facebook / YouTube / LinkedIn links |

Also worth doing before launch:
- Swap the solid-color photo placeholders (hero, about, and the three patient panels) for real photos — using a stock photo URL directly risked broken images if the link ever changes, so the placeholders were left as clean color blocks instead. Just replace the `<div class="...">` with an `<img src="your-photo.jpg" alt="...">` inside each `hero-figure`, `about-photo`, and `panel-photo` container.
- Review every FAQ answer and health library note — they're general placeholders, not medical claims.
- Confirm the WhatsApp message wording in `js/main.js` matches how you actually want requests worded.

## What was checked

- Every nav link scrolls to its matching section; legal page links go to their own pages.
- Both forms build a WhatsApp message and open `wa.me` — no data is stored by the site (no localStorage, no backend).
- Mobile menu, FAQ accordion and forms tested for basic interaction.
- No fake statistics, testimonials, registration number, or specialization were added — all left as explicit placeholders.
- Layout checked down to a narrow mobile width and up to desktop.
